Go to main.m for the instructions.

Consider using this library (aka. folder with a lot of stupid functions) if you want quick access to the help description of the functions, e.g. 
	>> help drawLine

Otherwise, consider using the self-contained version in:
	optVidoesSelfcontained.m